﻿using GiftOfGivers.Data;
using GiftOfGivers.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using QuestPDF.Fluent;
namespace GiftOfGivers.Controllers
{
    public class DonateController : Controller
    {
        private readonly ApplicationDbContext _context;

        public DonateController (ApplicationDbContext context)
        {
            _context = context;
        }
        [HttpGet]
        public IActionResult Index() => View(new Donation());

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Index (Donation donation)
        {
            if (!ModelState.IsValid) return View(donation);

                    donation.DonationDate = DateTime.Now;
            donation.CertificateNumber = $"GOTG-{DateTime.Now: yyyyMMdd}-{new Random ().Next(1000, 9999)}";

            _context.Donations.Add(donation);
            _context.SaveChanges();

            return RedirectToAction("Certificate", new {id = donation.DonationID});
        }
        public IActionResult Certificate (int id)
        {
            var donation = _context.Donations.Find(id);
            if (donation == null) return NotFound();

            var pdfBytes = Document.Create(container =>
            {
                container.Page(page =>
                {
                    page.Margin(40);
                    page.Header().Text("Gift of the Givers Foundation")
                    .FontSize(20).Bold();

                    page.Content().Column(col =>
                    {
                        col.Spacing(10);
                        col.Item().Text("Tax Deductibe Donation Certificate")
                        .FontSize(16).SemiBold();
                        col.Item().Text($"Certificate No: {donation.CertificateNumber}");
                        col.Item().Text($"Donor: {donation.DonorName ?? "Anonymous Guest"}");
                        col.Item().Text($"Amount: {donation.Currency} {donation.Amount:N2}");
                        col.Item().Text($"Type: {(donation.IsRecurring ? "Recurring" : "One-time")}");
                        col.Item().Text($"Date: {donation.DonationDate:: dd MMMM yyyy}");
                        col.Item().PaddingTop(20).Text("This is a placeholder certificate generated for protoype demonstration purposes only")
                        .Italic().FontSize(10);
                    });
                    page.Footer().AlignCenter().Text("Gift of the Givers Foundation - Disaster Relief");
                });
            }).GeneratePdf();
            return File(pdfBytes, "application/pdf", $"TaxCertificate_{donation.CertificateNumber}.pdf");
        }
    }
}
